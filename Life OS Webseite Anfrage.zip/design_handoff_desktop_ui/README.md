# Handoff: Kies Desktop UI (Alpen theme)

## Overview
A new wide-screen desktop UI for **Kies**, tim-stubbe/finance-app — a self-hosted personal finance / "Life OS" tool. Replaces the current mobile-first sidebar layout (`frontend/index.html` + `frontend/style.css`) with a desktop-optimized top-navigation layout and a new dark "Alpen" (Swiss-Alps photo) visual theme, built as a fifth theme option alongside the existing dark/light/yellow/alpen themes already in `style.css`.

## About the design file
`Kies-desktop-design.html` is a **design reference built in HTML** — a prototype showing the intended look, layout, and tab-switching behavior. It is NOT production code to copy in. It currently uses a Design Component runtime (`support.js`, `<sc-if>`, `<sc-for>` template tags) that only exists in the design tool — none of that is available in the real app.

**The task: recreate this design inside the existing Kies codebase** (`frontend/index.html`, `frontend/app.js`, `frontend/style.css` — vanilla HTML/CSS/JS, no build step, per the repo's own stack) using the app's existing patterns:
- Reuse the existing `.tab-content` / `data-tab` nav-switching mechanism already in `app.js` (see `nav-btn`, `.tab-content.active`) instead of the design file's React-like `<sc-if>` blocks.
- Add this as a **new theme** (`data-theme="alpen-desktop"` or similar) in `style.css`'s theme block pattern (see existing `:root[data-theme="alpen"]` block) — don't hardcode colors inline.
- The existing 18 tabs in `index.html` stay; this handoff only restyles/relayouts the top chrome (sidebar → top nav) and provides new visual treatment + richer content for the Hub and Investments tabs. Other tabs shown in the prototype (Dashboard, Buchungen, Konten, etc.) are simplified placeholders — keep the real, existing markup/logic for those tabs, just apply the new visual language (panels, tokens, typography) to them.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and the two fully-designed tabs (Hub, Investments) are final. The other 10 tabs are shown at low fidelity (structure/placement only) — apply the same visual language but keep the app's real data/behavior for those.

## Layout
- Full-bleed background: Matterhorn photo (`frontend/alpen-bg.jpg`, already in the repo, used at `background-size:cover; background-position:center 55%; opacity:.72`), with a dark gradient overlay on top: `linear-gradient(180deg, rgba(25,24,23,.30) 0%, rgba(25,24,23,.62) 42%, rgba(25,24,23,.94) 100%)`. Both layers must scale to the full scrollable page height, not just the first viewport — use `background-attachment:fixed` on an absolutely-positioned layer inside a `position:relative` full-height wrapper (see the design file's `.kies-bg` / `.kies-bg-gradient` classes), not `position:fixed` sized by `inset:0` (that only covers `100vh` and leaves tall tabs with a flat gray tail).
- Top navigation bar (replaces the current left sidebar): `position:sticky; top:0`, translucent dark background `rgba(20,19,18,.55)` with `backdrop-filter:blur(6px)`, bottom border `1px solid rgba(255,255,255,.14)`. Contains, left to right: logo mark + wordmark, horizontal nav links (flush, `gap:2px`, active link gets `border-bottom:2px solid var(--color-accent-400)` and full-opacity text `#f4f1ec`, inactive links `rgba(244,241,236,.62)`), then right-aligned: search box (`⌘K` hint) and a "Synchronisieren" outlined button.
- Content area: centered, `max-width:1440px`, `padding:30px 34px 50px`.
- Panel component (`.kies-panel`): `border:1px solid rgba(255,255,255,.14); padding:20px 22px; background:rgba(25,24,23,.4)`. Used for every card/section throughout.
- Row component (`.kies-row`): flex row, `padding:11px 0`, `border-bottom:1px solid rgba(255,255,255,.1)`, `font-size:12.5px`, last row has no border.
- Table (`.kies-table`): plain `border-collapse:collapse`, header cells uppercase/letter-spaced/dim with a stronger bottom border, body cells get a top hairline.

## Design tokens
Loaded from the **Classical** design system stylesheet (`_ds_bundle`/`styles.css` in the design tool — for the real app, port these values into `style.css`'s CSS custom properties, matching the existing `:root[data-theme="..."]` pattern):
- `--font-heading`: Cormorant Garamond (headings, display numbers) — weight 400 for display, 600 max for interface headings.
- `--font-body`: Lora (body text, UI labels).
- `--color-accent-300` / `-400` / `-600`: warm gold, e.g. `#e1ad66` (`-400`) — the sole accent color; used only as text/border/stroke, never as a large fill.
- Foreground on dark: `#f4f1ec` full text, `rgba(244,241,236,.5–.75)` for secondary/dim text.
- Dividers: `rgba(255,255,255,.1)` (row hairlines) to `rgba(255,255,255,.2)` (section header underline).
- Numbers are set with `font-variant-numeric: tabular-nums` everywhere they appear as figures (amounts, dates, percentages, table columns).
- Kicker labels (small caps section headers): `font-size:10px; letter-spacing:.2em; text-transform:uppercase; color:rgba(244,241,236,.5)`.

## Screens / Views

### Hub (fully designed)
- Header: date kicker + "Hub" H1 (Cormorant Garamond, 38px, weight 400).
- Two-column grid (`1.5fr 1fr`):
  - Left: net-worth panel — big tabular-nums number (56px), 30-day delta in accent color, an inline SVG line chart (gold stroke `#e1ad66`, subtle fill), then a "KI-Vorschläge" (AI suggestions) sub-section: each row shows a proposed change, a confidence %, and an outlined "Übernehmen" (accept) button.
  - Right column, stacked panels: "Umzug Schweiz" countdown (days-remaining number + thin progress bar + milestone text), "Termine & To-Dos" (calendar day number in heading font + task rows, checkbox squares for todos), "Abo-Fristen" (subscription renewal/cancellation deadlines).

### Investments (fully designed)
- Header with a "prices updated Xmin ago" note, right-aligned.
- Row of 4 stat cards: Depotwert (portfolio value), total P/L, dividends YTD, YTD return — each a kicker + large tabular number.
- Full-width panel: 5-year portfolio value line chart (SVG, same gold-stroke style as Hub), with year labels below.
- Three-column row:
  1. Donut chart "Nach Anlageklasse" (by asset class) — built as a `border-radius:50%` div with a CSS `conic-gradient` background and a solid-color center circle punched out via an absolutely-positioned inner div; legend list with color swatches.
  2. Donut chart "Nach Währung" (by currency), same technique.
  3. Heatmap "Rendite je Position" — small tile grid, each tile background-tinted gold (gain) or a muted red `rgba(198,90,80,…)` (loss), opacity/intensity scaled to the magnitude of return; ticker + % inside each tile.
- Full-width holdings table: Position, Symbol, Bestand (qty), Wert (value), Gewinn/Verlust (colored: gold for gain, muted red `#d68f86` for loss).

### Other 10 tabs (placeholder fidelity — Dashboard, Buchungen, Konten, Abos & Cashflow, Ziele, Schweiz, Schulden, To-Dos & Kalender, Fotos, KI-Assistent)
Each follows the same header pattern (kicker + H1) and reuses `.kies-panel` / `.kies-row` / `.kies-table` for its content, but only sketches 1-2 panels of illustrative content. **Keep the real Kies functionality for these tabs** — port their existing markup from `frontend/index.html` and just apply the new panel/token treatment, don't ship the placeholder copy.

## Interactions & behavior
- Top-nav tab switching: clicking a nav link swaps the visible tab. In the design prototype this is component state; in the real app, reuse the existing `data-tab` / `.tab-content.active` toggling already implemented in `frontend/app.js` — do not rebuild this mechanism.
- No other new interactions (this handoff is visual/layout; all existing app behavior — sync, forms, modals, etc. — is unchanged).

## Assets
- `frontend/alpen-bg.jpg` — already exists in the repo (used for the current `alpen` theme's background); reused as-is for this design's background photo.
- Logo mark: simple inline SVG mountain glyph (two overlapping triangular peaks) — see the `<svg>` in the design file's header; recreate as inline SVG, don't rasterize.
- Icons: none beyond the logo and a magnifying-glass search icon (inline SVG, stroke-based, matches existing icon style in `index.html`'s nav).

## Files
- `Kies-desktop-design.html` — the full design reference (open in a browser; depends on a `support.js` runtime that won't resolve outside the design tool — treat as visual/structural reference only, not a working page).
- `assets/alpen-bg.jpg` — the Matterhorn background photo, already in the repo at `frontend/alpen-bg.jpg`; included here too for convenience.
- `screenshots/01-hub.png`, `screenshots/02-investments.png`, `screenshots/03-investments-charts.png` — rendered captures of the two fully-designed tabs.
